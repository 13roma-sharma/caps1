package com.example.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Quote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String businessName;
    private String contactPerson;
    private String phone;
    private String email;
    private String address;

    private String businessType;
    private int numberOfEmployees;
    private double annualRevenue;
    private int yearsInBusiness;
    private int pastClaims;
    private String coverageLimit; // "1CR", "2CR", etc.
    private String location;

    private boolean addOnCyberLiability;
    private boolean addOnProductLiability;

    private double premium;
    private String status; // DRAFT, BOUND
    private LocalDate createdDate;
    private boolean deleted = false;
}