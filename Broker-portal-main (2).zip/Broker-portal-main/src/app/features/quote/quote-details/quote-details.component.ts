import { Component } from '@angular/core';

@Component({
  selector: 'app-quote-details',
  imports: [],
  templateUrl: './quote-details.component.html',
  styleUrl: './quote-details.component.css'
})
export class QuoteDetailsComponent {

}
