import { Component } from '@angular/core';

@Component({
  selector: 'app-quote-list',
  imports: [],
  templateUrl: './quote-list.component.html',
  styleUrl: './quote-list.component.css'
})
export class QuoteListComponent {

}
