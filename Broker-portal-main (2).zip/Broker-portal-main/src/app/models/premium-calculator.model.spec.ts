import { PremiumCalculatorModel } from './premium-calculator.model';

describe('PremiumCalculatorModel', () => {
  it('should create an instance', () => {
    expect(new PremiumCalculatorModel()).toBeTruthy();
  });
});
