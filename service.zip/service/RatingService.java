package com.example.service;

import com.example.entity.Quote;
import org.springframework.stereotype.Service;

@Service
public class RatingService {

    public double calculatePremium(Quote quote) {
        double basePremium = 8000.0; // Starting premium in INR

        // 1. Business Type Risk
        switch (quote.getBusinessType().toLowerCase()) {
            case "construction" -> basePremium += 20000;
            case "manufacturing" -> basePremium += 15000;
            case "retail" -> basePremium += 10000;
            case "it services" -> basePremium += 7000;
            default -> basePremium += 9000;
        }

        // 2. Annual Revenue
        double revenue = quote.getAnnualRevenue();
        if (revenue > 1_00_00_000) basePremium += 20000;
        else if (revenue > 50_00_000) basePremium += 12000;
        else basePremium += 5000;

        // 3. Years in Business
        if (quote.getYearsInBusiness() < 1) basePremium += 8000;
        else if (quote.getYearsInBusiness() <= 3) basePremium += 5000;
        else basePremium += 2000;

        // 4. Claims History
        basePremium += quote.getPastClaims() * 3000;

        // 5. Number of Employees
        basePremium += quote.getNumberOfEmployees() * 750;

        // 6. Add-ons
        if (quote.isAddOnCyberLiability()) basePremium += 7000;
        if (quote.isAddOnProductLiability()) basePremium += 10000;

        // 7. Coverage Limit
        switch (quote.getCoverageLimit()) {
            case "2CR" -> basePremium += 10000;
            case "1CR" -> basePremium += 5000;
            default -> basePremium += 3000;
        }

        return basePremium;
    }
}