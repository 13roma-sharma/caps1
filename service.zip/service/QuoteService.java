package com.example.service;

import com.example.entity.Quote;
import com.example.repository.QuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class QuoteService {

    @Autowired
    private QuoteRepository quoteRepository;

    @Autowired
    private RatingService ratingService;

    public Quote createQuote(Quote quote) {
        quote.setPremium(ratingService.calculatePremium(quote));
        quote.setStatus("DRAFT");
        quote.setCreatedDate(LocalDate.now());
        return quoteRepository.save(quote);
    }

    public List<Quote> getAllQuotes() {
        return quoteRepository.findByDeletedFalse();
    }

    public Optional<Quote> getQuoteById(Long id) {
        return quoteRepository.findById(id).filter(q -> !q.isDeleted());
    }

    public Quote updateQuote(Long id, Quote updated) {
        return quoteRepository.findById(id).map(existing -> {
            updated.setId(id);
            updated.setCreatedDate(existing.getCreatedDate());
            updated.setPremium(ratingService.calculatePremium(updated));
            return quoteRepository.save(updated);
        }).orElseThrow(() -> new RuntimeException("Quote not found"));
    }

    public void softDeleteQuote(Long id) {
        quoteRepository.findById(id).ifPresent(q -> {
            q.setDeleted(true);
            quoteRepository.save(q);
        });
    }
}
